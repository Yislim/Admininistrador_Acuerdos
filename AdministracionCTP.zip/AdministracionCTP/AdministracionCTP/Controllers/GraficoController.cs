﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AdministracionCTP.Models;
using AdministracionCTP.Permisos;

namespace AdministracionCTP.Controllers
{
    [Authorize]
    public class GraficoController : Controller
    {
      
        // GET: Grafico
        public ActionResult GraficoDeBarra()
        {
            return View();
        }

        public ActionResult Grafico()
        {
            return View();
        }

        [HttpGet]
        public JsonResult ListarGrafico()
        {
            List<ElementJsonIntKey> listaNueva = new List<ElementJsonIntKey>();
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                listaNueva = (from a in BaseDatos.Estado
                              select new ElementJsonIntKey
                              {
                                  Value = a.Acuerdo.Count,
                                  Text = a.Estado1
                              }
                         ).ToList();
            }
            return Json(listaNueva, JsonRequestBehavior.AllowGet);
        }

        public class ElementJsonIntKey
        {
            public int Value { get; set; }
            public String Text { get; set; }
        }


        public JsonResult RespuestaPastel()
        {
            GraficoPastel pastel = new GraficoPastel();
            return Json(pastel.obtenerDatos(), JsonRequestBehavior.AllowGet);
        }

    }
}