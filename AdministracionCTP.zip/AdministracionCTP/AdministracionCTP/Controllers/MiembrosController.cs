﻿using AdministracionCTP.Models;
using AdministracionCTP.Permisos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AdministracionCTP.Controllers
{
    [Authorize]
    [PermisosRol((int)RolUsuario.Administrador)]
    public class MiembrosController : Controller
    {
        // GET: Miembros
        public ActionResult Crear()
        {
            return View("Crear");
        }

        public ActionResult ConsultarMiembro()
        {
            Miembro instancia = new Miembro();
            var miembro = instancia.ConsultarMiembro(true);

            return View("ConsultarMiembro", miembro);

        }


        [HttpPost]
        public ActionResult AgregarMiembro(Miembros miembro)
        {
            Miembro instancia = new Miembro();
            var resultado = instancia.RegistrarMiembro(miembro);

            if (resultado != true)
            {
                Miembro miembrovacio = new Miembro();
                return View("AgregarMiembro", miembrovacio);
            }
            else
            {
                return RedirectToAction("ConsultarMiembro", "Miembros");
            }
        }

        [HttpPost]
        public ActionResult EliminarMiembro(int idMiembros)
        {
            Miembro instancia = new Miembro();
            var resultado = instancia.EliminarMiembro(idMiembros);

            if (resultado != true)
            {
                return RedirectToAction("ConsultarMiembro");
            }
            else
            {
                return RedirectToAction("ConsultarMiembro");
            }
        }

        [HttpGet]
        public ActionResult EditarMiembro(int idMiembros)
        {
            Miembro instancia = new Miembro();
            var resultado = instancia.ConsultarMiembroID(idMiembros);

            Miembros Miembrolista = new Miembros();

            foreach (var item in resultado)
            {
                Miembrolista.idMiembros = item.idMiembros;
                Miembrolista.Nombres = item.Nombres;
            }

            if (resultado.Count > 0)
                return View("EditarMiembro", Miembrolista);
            else
                return RedirectToAction("ConsultarMiembro");
        }

        [HttpPost]
        public ActionResult EditarMiembro(Miembros miembro)
        {
            return View();
        }

        [HttpPost]
        public ActionResult EditarMiembroDatos(Miembros miembro)
        {
            Miembro instancia = new Miembro();
            var resultado = instancia.ActualizarMiembros(miembro);

            if (resultado != true)
            {
                return View();
            }
            else
            {
                return RedirectToAction("ConsultarMiembro");
            }
        }

    }
}

