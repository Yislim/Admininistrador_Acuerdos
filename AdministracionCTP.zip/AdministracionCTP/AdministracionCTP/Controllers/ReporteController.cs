﻿using AdministracionCTP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AdministracionCTP.Controllers
{
    [Authorize]
    public class ReporteController : Controller
    {
        // GET: Reporte
        [Authorize]
        public ActionResult Reporte()
        {
            List<Acuerdo> list; using (var db = new AcuerdoCTPEntities())
            {
                list = (from a in db.Acuerdo where a.Id_Estado == 1 || a.Id_Estado == 2 select a).ToList();
            }
            return View(list);
        }

    }
}