﻿using AdministracionCTP.Models;
using AdministracionCTP.Permisos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AdministracionCTP.Controllers
{
    [Authorize]
    [PermisosRol((int)RolUsuario.Administrador)]
    public class AcuerdoController : Controller
    {
        // GET: Acuerdo
        public ActionResult Crear()
        {
            Acuerdos instancia = new Acuerdos();

            //Consulta la lista de la tabla estado
            var Estado = instancia.ConsultarEstado();
            List<SelectListItem> combo = new List<SelectListItem>();

            //Consulta la lista de la tabla miembro
            var Miembros = instancia.ConsultarMiembros();
            List<SelectListItem> combo2 = new List<SelectListItem>();

            //Consulta la lista de la tabla comisiones
            var Comisiones = instancia.ConsultarComisiones();
            List<SelectListItem> combo3 = new List<SelectListItem>();

            foreach (var item in Estado)
            {
                combo.Add(new SelectListItem { Value = item.Id_Estado.ToString(), Text = item.Estado1 });
            }
            ViewBag.ListaEstado = combo.ToList();
            foreach (var item in Miembros)
            {
                combo2.Add(new SelectListItem { Value = item.idMiembros.ToString(), Text = item.Nombres });
            }
            ViewBag.ListaMiembros = combo2.ToList();

            foreach (var item in Comisiones)
            {
                combo3.Add(new SelectListItem { Value = item.idComisiones.ToString(), Text = item.NombreComision });
            }
            ViewBag.ListaComisiones = combo3.ToList();


            return View("Crear");
        }

        public ActionResult ConsultarAcuerdo()
        {
            Acuerdos instancia = new Models.Acuerdos();
            var acuerdo = instancia.ConsultarAcuerdo(true);

            var Estado = instancia.ConsultarEstado();
            List<SelectListItem> combo = new List<SelectListItem>();

            var Miembros = instancia.ConsultarMiembros();
            List<SelectListItem> combo2 = new List<SelectListItem>();

            var Comisiones = instancia.ConsultarComisiones();
            List<SelectListItem> combo3 = new List<SelectListItem>();

            foreach (var item in Estado)
            {
                combo.Add(new SelectListItem { Value = item.Id_Estado.ToString(), Text = item.Estado1 });
            }
            ViewBag.ListaEstado = combo.ToList();
            foreach (var item in Miembros)
            {
                combo2.Add(new SelectListItem { Value = item.idMiembros.ToString(), Text = item.Nombres });
            }
            ViewBag.ListaMiembros = combo2.ToList();

            foreach (var item in Comisiones)
            {
                combo3.Add(new SelectListItem { Value = item.idComisiones.ToString(), Text = item.NombreComision });
            }
            ViewBag.ListaComisiones = combo3.ToList();

            return View("ConsultarAcuerdo", acuerdo);

        }


        [HttpPost]
        public ActionResult AgregarAcuerdo(Acuerdo acuerdo)
        {
            Acuerdos instancia = new Acuerdos();
            var resultado = instancia.RegistrarAcuerdo(acuerdo);

            if (resultado != true)
            {
                Acuerdo acuerdovacio = new Acuerdo();
                return View("AgregarAcuerdo", acuerdovacio);
            }
            else
            {
                return RedirectToAction("ConsultarAcuerdo", "acuerdo");
            }
        }

        [HttpPost]
        public ActionResult EliminarAcuerdo(int IdAcuerdo)
        {
            Acuerdos instancia = new Acuerdos();
            var resultado = instancia.EliminarAcuerdo(IdAcuerdo);

            if (resultado != true)
            {
                return RedirectToAction("ConsultarAcuerdo");
            }
            else
            {
                return RedirectToAction("ConsultarAcuerdo");
            }
        }

        [HttpGet]
        public ActionResult EditarAcuerdo(int IdAcuerdo)
        {
            Acuerdos instancia = new Acuerdos();
            var resultado = instancia.ConsultarAcuerdoID(IdAcuerdo);

            Acuerdo Acuerdolista = new Acuerdo();

            var Estado = instancia.ConsultarEstado();
            List<SelectListItem> combo = new List<SelectListItem>();

            var Miembros = instancia.ConsultarMiembros();
            List<SelectListItem> combo2 = new List<SelectListItem>();

            var Comisiones = instancia.ConsultarComisiones();
            List<SelectListItem> combo3 = new List<SelectListItem>();

            foreach (var item in Estado)
            {
                combo.Add(new SelectListItem { Value = item.Id_Estado.ToString(), Text = item.Estado1 });
            }
            ViewBag.ListaEstado = combo.ToList();
            foreach (var item in Miembros)
            {
                combo2.Add(new SelectListItem { Value = item.idMiembros.ToString(), Text = item.Nombres });
            }
            ViewBag.ListaMiembros = combo2.ToList();

            foreach (var item in Comisiones)
            {
                combo3.Add(new SelectListItem { Value = item.idComisiones.ToString(), Text = item.NombreComision });
            }
            ViewBag.ListaComisiones = combo3.ToList();

            foreach (var item in resultado)
            {
                Acuerdolista.IdAcuerdo = item.IdAcuerdo;
                Acuerdolista.Nombre = item.Nombre;
                Acuerdolista.idComisiones = item.idComisiones;
                Acuerdolista.DetalleAcuerdo = item.DetalleAcuerdo;
                Acuerdolista.Id_Estado = item.Id_Estado;
                Acuerdolista.idMiembros = item.idMiembros;
                Acuerdolista.NombreComision = item.NombreComision;
                Acuerdolista.Nombres = item.Nombres;
                Acuerdolista.FechaInicio = item.FechaInicio;
                Acuerdolista.FechaEntrega = item.FechaEntrega;
            }

            if (resultado.Count > 0)
                return View("EditarAcuerdo", Acuerdolista);
            else
                return RedirectToAction("ConsultarAcuerdo");
        }

        [HttpPost]
        public ActionResult EditarAcuerdo(Acuerdo acuerdo)
        {
            return View();
        }

        [HttpPost]
        public ActionResult EditarAcuerdoDatos(Acuerdo acuerdo)
        {
            Acuerdos instancia = new Acuerdos();
            var resultado = instancia.ActualizarAcuerdo(acuerdo);

            var Estado = instancia.ConsultarEstado();
            List<SelectListItem> combo = new List<SelectListItem>();

            var Miembros = instancia.ConsultarMiembros();
            List<SelectListItem> combo2 = new List<SelectListItem>();

            var Comisiones = instancia.ConsultarComisiones();
            List<SelectListItem> combo3 = new List<SelectListItem>();

            foreach (var item in Estado)
            {
                combo.Add(new SelectListItem { Value = item.Id_Estado.ToString(), Text = item.Estado1 });
            }
            ViewBag.ListaEstado = combo.ToList();
            foreach (var item in Miembros)
            {
                combo2.Add(new SelectListItem { Value = item.idMiembros.ToString(), Text = item.Nombres });
            }
            ViewBag.ListaMiembros = combo2.ToList();

            foreach (var item in Comisiones)
            {
                combo3.Add(new SelectListItem { Value = item.idComisiones.ToString(), Text = item.NombreComision });
            }
            ViewBag.ListaComisiones = combo3.ToList();

            if (resultado != true)
            {
                return View();
            }
            else
            {
                return RedirectToAction("ConsultarAcuerdo");
            }
        }


    }
}
