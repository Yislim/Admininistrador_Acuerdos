﻿using AdministracionCTP.Models;
using AdministracionCTP.Permisos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AdministracionCTP.Controllers
{
    [Authorize]
    [PermisosRol((int)RolUsuario.Administrador)]
    public class ComisionController : Controller
    {
        // GET: Comision
        public ActionResult Crear()
        {
            ComisionModel instancia = new ComisionModel();

            var Acuerdo = instancia.ConsultarAcuerdo();
            List<SelectListItem> combo = new List<SelectListItem>();

            var Miembros = instancia.ConsultarMiembros();
            List<SelectListItem> combo2 = new List<SelectListItem>();

            var Sesion = instancia.ConsultarSesion();
            List<SelectListItem> combo4 = new List<SelectListItem>();

            foreach (var item in Acuerdo)
            {
                combo.Add(new SelectListItem { Value = item.IdAcuerdo.ToString(), Text = item.Nombre });
            }
            ViewBag.ListaAcuerdo = combo.ToList();
            foreach (var item in Miembros)
            {
                combo2.Add(new SelectListItem { Value = item.idMiembros.ToString(), Text = item.Nombres });
            }
            ViewBag.ListaMiembros = combo2.ToList();

            foreach (var item in Sesion)
            {
                combo4.Add(new SelectListItem { Value = item.IdSesion.ToString(), Text = item.TipoSesion });
            }
            ViewBag.ListaSesion = combo4.ToList();


            return View("Crear");
        }

        public ActionResult ConsultarComision()
        {
            ComisionModel instancia = new ComisionModel();
            var comision = instancia.ConsultarComision(true);

            var Acuerdo = instancia.ConsultarAcuerdo();
            List<SelectListItem> combo = new List<SelectListItem>();

            var Miembros = instancia.ConsultarMiembros();
            List<SelectListItem> combo2 = new List<SelectListItem>();

            var Sesion = instancia.ConsultarSesion();
            List<SelectListItem> combo4 = new List<SelectListItem>();

            foreach (var item in Acuerdo)
            {
                combo.Add(new SelectListItem { Value = item.IdAcuerdo.ToString(), Text = item.Nombre });
            }
            ViewBag.ListaAcuerdo = combo.ToList();
            foreach (var item in Miembros)
            {
                combo2.Add(new SelectListItem { Value = item.idMiembros.ToString(), Text = item.Nombres });
            }
            ViewBag.ListaMiembros = combo2.ToList();

            foreach (var item in Sesion)
            {
                combo4.Add(new SelectListItem { Value = item.IdSesion.ToString(), Text = item.TipoSesion });
            }
            ViewBag.ListaSesion = combo4.ToList();
            return View("ConsultarComision", comision);

        }


        [HttpPost]
        public ActionResult AgregarComision(Comision comision)
        {
            ComisionModel instancia = new ComisionModel();
            var resultado = instancia.RegistrarComision(comision);

            if (resultado != true)
            {
                Comision comisionvacio = new Comision();
                return View("AgregarComision", comisionvacio);
            }
            else
            {
                return RedirectToAction("ConsultarComision", "comision");
            }
        }

        [HttpPost]
        public ActionResult EliminarComision(int IdComision)
        {
            ComisionModel instancia = new ComisionModel();
            var resultado = instancia.EliminarComision(IdComision);

            if (resultado != true)
            {
                return RedirectToAction("ConsultarComision");
            }
            else
            {
                return RedirectToAction("ConsultarComision");
            }
        }

        [HttpGet]
        public ActionResult EditarComision(int IdComision)
        {
            ComisionModel instancia = new ComisionModel();
            var resultado = instancia.ConsultarComisionID(IdComision);

            Comision Comisionlista = new Comision();

            var Acuerdo = instancia.ConsultarAcuerdo();
            List<SelectListItem> combo = new List<SelectListItem>();

            var Miembros = instancia.ConsultarMiembros();
            List<SelectListItem> combo2 = new List<SelectListItem>();

            var Sesion = instancia.ConsultarSesion();
            List<SelectListItem> combo4 = new List<SelectListItem>();

            foreach (var item in Acuerdo)
            {
                combo.Add(new SelectListItem { Value = item.IdAcuerdo.ToString(), Text = item.Nombre });
            }
            ViewBag.ListaAcuerdo = combo.ToList();
            foreach (var item in Miembros)
            {
                combo2.Add(new SelectListItem { Value = item.idMiembros.ToString(), Text = item.Nombres });
            }
            ViewBag.ListaMiembros = combo2.ToList();

            foreach (var item in Sesion)
            {
                combo4.Add(new SelectListItem { Value = item.IdSesion.ToString(), Text = item.TipoSesion });
            }
            ViewBag.ListaSesion = combo4.ToList();

            foreach (var item in resultado)
            {
                Comisionlista.IdComision = item.IdComision;
                Comisionlista.FechaRealizacion = item.FechaRealizacion;
                Comisionlista.IdSesion = item.IdSesion;
                Comisionlista.Nombres = item.Nombres;
                Comisionlista.IdAcuerdo = item.IdAcuerdo;
                Comisionlista.Nombre = item.Nombre;
                Comisionlista.idMiembros = item.idMiembros;

            }

            if (resultado.Count > 0)
                return View("EditarComision", Comisionlista);
            else
                return RedirectToAction("ConsultarComision");
        }

        [HttpPost]
        public ActionResult EditarComision(Comision comision)
        {
            return View();
        }

        [HttpPost]
        public ActionResult EditarComisionDatos(Comision comision)
        {
            ComisionModel instancia = new ComisionModel();
            var resultado = instancia.ActualizarComision(comision);

            var Acuerdo = instancia.ConsultarAcuerdo();
            List<SelectListItem> combo = new List<SelectListItem>();

            var Miembros = instancia.ConsultarMiembros();
            List<SelectListItem> combo2 = new List<SelectListItem>();

            var Sesion = instancia.ConsultarSesion();
            List<SelectListItem> combo4 = new List<SelectListItem>();

            foreach (var item in Acuerdo)
            {
                combo.Add(new SelectListItem { Value = item.IdAcuerdo.ToString(), Text = item.Nombre });
            }
            ViewBag.ListaAcuerdo = combo.ToList();
            foreach (var item in Miembros)
            {
                combo2.Add(new SelectListItem { Value = item.idMiembros.ToString(), Text = item.Nombres });
            }
            ViewBag.ListaMiembros = combo2.ToList();

            foreach (var item in Sesion)
            {
                combo4.Add(new SelectListItem { Value = item.IdSesion.ToString(), Text = item.TipoSesion });
            }
            ViewBag.ListaSesion = combo4.ToList();

            if (resultado != true)
            {
                return View();
            }
            else
            {
                return RedirectToAction("ConsultarComision");
            }
        }


        public class ElementJsonIntKey
        {
            public int Value { get; set; }
            public String Text { get; set; }
        }


        [HttpGet]
        public JsonResult ListarDistrito(int idMiembros)
        {
            List<ElementJsonIntKey> list = new List<ElementJsonIntKey>();
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                list = (from a in BaseDatos.Miembros
                        where a.idMiembros == idMiembros
                        select new ElementJsonIntKey
                        {
                            Value = a.idMiembros,
                            Text = a.Nombres
                        }
                         ).ToList();
            }
            return Json(list, JsonRequestBehavior.AllowGet);
        }

    }
}
public enum RolUsuario
{
    Administrador = 1,
    Reportes = 2,
    HR = 3
}