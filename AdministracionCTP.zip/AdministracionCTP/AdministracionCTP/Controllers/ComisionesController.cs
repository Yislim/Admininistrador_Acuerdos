﻿using AdministracionCTP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AdministracionCTP.Controllers
{
    [Authorize]
    public class ComisionesController : Controller
    {
        // GET: Comisiones
        public ActionResult Crear()
        {
            return View("Crear");
        }

        public ActionResult ConsultarComisiones()
        {
            ComisionesModel instancia = new ComisionesModel();
            var comisiones = instancia.ConsultarComisiones(true);

            return View("ConsultarComisiones", comisiones);

        }


        [HttpPost]
        public ActionResult AgregarComisiones(Comisiones comisiones)
        {
            ComisionesModel instancia = new ComisionesModel();
            var resultado = instancia.RegistrarComisiones(comisiones);

            if (resultado != true)
            {
                Comisiones comisionesvacio = new Comisiones();
                return View("AgregarComisiones", comisionesvacio);
            }
            else
            {
                return RedirectToAction("ConsultarComisiones", "Comisiones");
            }
        }

        [HttpPost]
        public ActionResult EliminarComisiones(int idComisiones)
        {
            ComisionesModel instancia = new ComisionesModel();
            var resultado = instancia.EliminarComisiones(idComisiones);

            if (resultado != true)
            {
                return RedirectToAction("ConsultarComisiones");
            }
            else
            {
                return RedirectToAction("ConsultarComisiones");
            }
        }



    }
}