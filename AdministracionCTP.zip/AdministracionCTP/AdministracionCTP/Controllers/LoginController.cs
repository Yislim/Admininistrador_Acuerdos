﻿using AdministracionCTP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;

namespace AdministracionCTP.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        [HttpGet]
        public ActionResult IniciarSesion()
        {
            return View();
        }

        [HttpPost]
        public ActionResult IniciarSesion(Usuario usuario)
        {
            IniciarSesion model = new IniciarSesion();
            var resultado = model.ValidarUsuario(usuario);
            if (resultado != null)
            {
                Session["Rol"] = resultado.ID_Rol;
                FormsAuthentication.SetAuthCookie(resultado.Correo, false);
                Session["Usuario"] = resultado;
                return RedirectToAction("Index", "Home");
            }
            else
            {
                ViewBag.mensajevalidacion = "El campo correo electrónico o contraseña no es correcto, intente de nuevo.";
            }
                return View(new Usuario());
        }


        public ActionResult CerrarSesion()
        {
            FormsAuthentication.SignOut();
            Session["Usuario"] = null;
            return RedirectToAction("IniciarSesion", "Login");
        }

    }
}