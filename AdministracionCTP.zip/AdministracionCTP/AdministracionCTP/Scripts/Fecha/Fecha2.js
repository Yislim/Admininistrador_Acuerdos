﻿$(function () {
    $("#fechaE").datepicker({
        format: 'yyyy/mm/dd',
        firstDay: 1,
        autoclose: true,
        todayBtn: true,
        pickerPosition: "bottom-left",
        language: 'es',
        weekStart: 1,
        todayHighlight: 1

    });
});