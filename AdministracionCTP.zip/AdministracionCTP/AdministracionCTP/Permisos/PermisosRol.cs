﻿using AdministracionCTP.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace AdministracionCTP.Permisos
{
    public class PermisosRol : ActionFilterAttribute
    {
        private int idRol;
        public PermisosRol(int ID_Rol)
        {
            idRol = ID_Rol;
            
        }

        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (HttpContext.Current.Session["Usuario"] != null)
            {
                Usuario usuario = HttpContext.Current.Session["Usuario"] as Usuario;
                if (usuario.ID_Rol != this.idRol)
                {
                    filterContext.Result = new RedirectResult("/Home/SinPermiso");
                }
            }
            base.OnActionExecuted(filterContext);
        }


    }
}