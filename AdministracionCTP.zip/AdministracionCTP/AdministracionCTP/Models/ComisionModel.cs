﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdministracionCTP.Models
{
    public class ComisionModel
    {

        public List<Comision> ConsultarComision(bool ordenada)
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Comision>();

                consulta = (from a in BaseDatos.Comision
                            select a).ToList();

                if (consulta.Count > 0)
                    return consulta;
                else
                    return new List<Comision>();
            }
        }

        public Boolean RegistrarComision(Comision comision)
        {
            try
            {
                using (var bd = new AcuerdoCTPEntities())
                {
                    // Registro de comision
                    bd.Comision.Add(comision);
                    try
                    {
                        bd.SaveChanges();
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Boolean EliminarComision(int IdComision)
        {
            try
            {
                using (var bd = new AcuerdoCTPEntities())
                {
                    // Eliminar comision
                    var IdComisionEliminar = (from a in bd.Comision
                                             where a.IdComision == IdComision
                                             select a).First();
                    bd.Comision.Remove(IdComisionEliminar);
                    bd.SaveChanges();
                }
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<Comision> ConsultarComisionID(int IdComision)
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Comision>();
                consulta = (from a in BaseDatos.Comision
                            where a.IdComision == IdComision
                            select a).ToList();

                return consulta;
            }
        }

        public Boolean ActualizarComision(Comision comision)
        {
            try
            {
                using (var bd = new AcuerdoCTPEntities())
                {
                    // Registro de comision
                    var query = (from a in bd.Comision
                                 where a.IdComision == comision.IdComision
                                 select a).FirstOrDefault();

                    query.IdComision = comision.IdComision;
                    query.idMiembros = comision.idMiembros;
                    query.Nombres = comision.Nombres;
                    query.FechaRealizacion = comision.FechaRealizacion;
                    query.IdSesion = comision.IdSesion;
                    query.IdAcuerdo = comision.IdAcuerdo;
                    query.Nombre = comision.Nombre;

                    bd.SaveChanges();

                }
                return true;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public List<Sesion> ConsultarSesion()
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Sesion>();

                consulta = (from a in BaseDatos.Sesion
                            select a).ToList();

                if (consulta.Count > 0)
                    return consulta;
                else
                    return new List<Sesion>();

            }
        }


        public List<Acuerdo> ConsultarAcuerdo()
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Acuerdo>();

                consulta = (from a in BaseDatos.Acuerdo
                            select a).ToList();

                if (consulta.Count > 0)
                    return consulta;
                else
                    return new List<Acuerdo>();

            }
        }
        public List<Miembros> ConsultarMiembros()
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Miembros>();

                consulta = (from a in BaseDatos.Miembros
                            select a).ToList();

                if (consulta.Count > 0)
                    return consulta;
                else
                    return new List<Miembros>();
            }
        }

    }
}