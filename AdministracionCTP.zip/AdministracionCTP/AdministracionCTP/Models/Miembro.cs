﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdministracionCTP.Models
{
    public class Miembro
    {
        public List<Miembros> ConsultarMiembro(bool ordenada)
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Miembros>();

                consulta = (from a in BaseDatos.Miembros
                            select a).ToList();

                if (consulta.Count > 0)
                    return consulta;
                else
                    return new List<Miembros>();
            }
        }

        public Boolean RegistrarMiembro(Miembros miembro)
        {
            try
            {
                using (var bd = new AcuerdoCTPEntities())
                {
                    // Registro de miembro
                    bd.Miembros.Add(miembro);
                    try
                    {
                        bd.SaveChanges();
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Boolean EliminarMiembro(int idMiembros)
        {
            try
            {
                using (var bd = new AcuerdoCTPEntities())
                {
                    // Eliminar miembro
                    var IdMiembroEliminar = (from a in bd.Miembros
                                             where a.idMiembros == idMiembros
                                             select a).First();
                    bd.Miembros.Remove(IdMiembroEliminar);
                    bd.SaveChanges();
                }
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<Miembros> ConsultarMiembroID(int idMiembros)
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Miembros>();
                consulta = (from a in BaseDatos.Miembros
                            where a.idMiembros == idMiembros
                            select a).ToList();

                return consulta;
            }
        }

        public Boolean ActualizarMiembros(Miembros miembro)
        {
            try
            {
                using (var bd = new AcuerdoCTPEntities())
                {
                    // Registro de miembro
                    var query = (from a in bd.Miembros
                                 where a.idMiembros == miembro.idMiembros
                                 select a).FirstOrDefault();

                    query.Nombres = miembro.Nombres;
                    query.idMiembros = miembro.idMiembros;

                    bd.SaveChanges();

                }
                return true;
            }
            catch (Exception)
            {
                throw;
            }

        }

    }
}