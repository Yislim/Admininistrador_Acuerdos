﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdministracionCTP.Models
{
    public class ComisionesModel
    {
        public List<Comisiones> ConsultarComisiones(bool ordenada)
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Comisiones>();

                consulta = (from a in BaseDatos.Comisiones
                            select a).ToList();

                if (consulta.Count > 0)
                    return consulta;
                else
                    return new List<Comisiones>();
            }
        }

        public Boolean RegistrarComisiones(Comisiones comision)
        {
            try
            {
                using (var bd = new AcuerdoCTPEntities())
                {
                    // Registro de comision
                    bd.Comisiones.Add(comision);
                    try
                    {
                        bd.SaveChanges();
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public Boolean EliminarComisiones(int idComisiones)
        {
            try
            {
                using (var bd = new AcuerdoCTPEntities())
                {
                    // Eliminar miembro
                    var IdComisionesEliminar = (from a in bd.Comisiones
                                             where a.idComisiones == idComisiones
                                             select a).First();
                    bd.Comisiones.Remove(IdComisionesEliminar);
                    bd.SaveChanges();
                }
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<Comisiones> ConsultarComisionesID(int idComisiones)
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Comisiones>();
                consulta = (from a in BaseDatos.Comisiones
                            where a.idComisiones == idComisiones
                            select a).ToList();

                return consulta;
            }
        }



    }
}