﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdministracionCTP.Models
{
    public class Acuerdos
    {
        public List<Acuerdo> ConsultarAcuerdo(bool ordenada)
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Acuerdo>();

                consulta = (from a in BaseDatos.Acuerdo
                            select a).ToList();

                if (consulta.Count > 0)
                    return consulta;
             else
                return new List<Acuerdo>();
            }
        }

        public Boolean RegistrarAcuerdo(Acuerdo acuerdo)
        {

                using (var bd = new AcuerdoCTPEntities())
                {
                    // Registro de acuerdo
                    bd.Acuerdo.Add(acuerdo);
                    try
                    {
                        bd.SaveChanges();
                    }
                    catch (Exception e)
                    {
                        throw e;
                    }
                }
                return true;
        }

        public Boolean EliminarAcuerdo(int IdAcuerdo)
        {
            try
            {
                using (var bd = new AcuerdoCTPEntities())
                {
                    // Eliminar acuerdo
                    var IdAcuerdoEliminar = (from a in bd.Acuerdo
                         where a.IdAcuerdo == IdAcuerdo select a).First();
                    bd.Acuerdo.Remove(IdAcuerdoEliminar);
                    bd.SaveChanges();
                }
                return true;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public List<Acuerdo> ConsultarAcuerdoID(int IdAcuerdo)
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Acuerdo>();
                consulta = (from a in BaseDatos.Acuerdo
                            where a.IdAcuerdo == IdAcuerdo
                            select a).ToList();

                return consulta;
            }
        }

        public Boolean ActualizarAcuerdo(Acuerdo acuerdo)
        {
            try
            {
                using (var bd = new AcuerdoCTPEntities())
                {
                    // Registro de acuerdo
                    var query = (from a in bd.Acuerdo
                                 where a.IdAcuerdo == acuerdo.IdAcuerdo
                                 select a).FirstOrDefault();

                    query.Nombre = acuerdo.Nombre;
                    query.DetalleAcuerdo = acuerdo.DetalleAcuerdo;
                    query.idComisiones = acuerdo.idComisiones;
                    query.NombreComision = acuerdo.NombreComision;
                    query.Id_Estado = acuerdo.Id_Estado;
                    query.idMiembros = acuerdo.idMiembros;
                    query.Nombres = acuerdo.Nombres;
                    query.FechaInicio = acuerdo.FechaInicio;
                    query.FechaEntrega = acuerdo.FechaEntrega;

                    bd.SaveChanges();

                }
                return true;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public List<Estado> ConsultarEstado()
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Estado>();

                consulta = (from a in BaseDatos.Estado
                            select a).ToList();

                if (consulta.Count > 0)
                    return consulta;
                else
                    return new List<Estado>();

            }
        }

        public List<Miembros> ConsultarMiembros()
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Miembros>();

                consulta = (from a in BaseDatos.Miembros
                            select a).ToList();

                if (consulta.Count > 0)
                    return consulta;
                else
                    return new List<Miembros>();
            }
        }

        public List<Comisiones> ConsultarComisiones()
        {
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                var consulta = new List<Comisiones>();

                consulta = (from a in BaseDatos.Comisiones
                            select a).ToList();

                if (consulta.Count > 0)
                    return consulta;
                else
                    return new List<Comisiones>();

            }
        }

    }
}