﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdministracionCTP.Models
{
    public class GraficoPastel
    {
        public string name { get; set; }
        public double y { get; set; }

        public bool sliced { get; set; }

        public bool selected { get; set; }


        public GraficoPastel()
        {

        }

        public GraficoPastel(string name, double y, bool sliced = false, bool selected = false)
        {
            this.name = name;
            this.y = y;
            this.sliced = sliced;
            this.selected = selected;
        }

        public List<GraficoPastel> obtenerDatos()
        {
            List<GraficoPastel> lista = new List<GraficoPastel>();
            using (var BaseDatos = new AcuerdoCTPEntities())
            {
                lista = (from a in BaseDatos.Acuerdo
                         select new GraficoPastel
                         {
                             y = a.Comision.Count,
                             name = a.NombreComision,
                         }
                         ).ToList();
            }

            return lista;
        }

    }
}