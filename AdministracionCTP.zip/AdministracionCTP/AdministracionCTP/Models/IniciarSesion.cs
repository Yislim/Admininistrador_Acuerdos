﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AdministracionCTP.Models
{
    public class IniciarSesion
    {
        public Usuario ValidarUsuario(Usuario usuario)
        {
            using (var contexto = new AcuerdoCTPEntities())
            {
                var resultado = (from x in contexto.Usuario where x.Correo == usuario.Correo && x.Clave == usuario.Clave select x).FirstOrDefault();

                if (resultado != null)
                {
                    return resultado;
                }
                else
                {
                    return null;
                }
            }
        }

    }
}